key = input()
try:
  key = int(key)
  print('Key could be correct')
except ValueError:
  print('Key is definetely not correct')